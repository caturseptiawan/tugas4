 <?php
$xml=simplexml_load_file("books.xml") or die("Error: Cannot create object");
echo $xml->book[0]->author . "<br>";
echo $xml->book[0]->title . "<br>";
echo $xml->book[0]->publisher . "<br>";

?> 